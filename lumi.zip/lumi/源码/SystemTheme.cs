using System;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Media;
using Microsoft.Win32;

namespace lumi
{
    internal static class SystemTheme
    {
        [DllImport("dwmapi.dll")]
        static extern int DwmGetColorizationColor(out uint color, out bool opaque);
        internal static bool Dark;
        internal static void Reload()
        {
            bool dark = false;
            uint accent = 0xff537fbd;
            try
            {
                using (var k = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize"))
                    dark = k != null && Convert.ToInt32(k.GetValue("AppsUseLightTheme", 1)) == 0;
                bool opaque;
                uint native;
                if (DwmGetColorizationColor(out native, out opaque) == 0) accent = native;
                // Explorer's menu accent is independent of the optional title-bar tint.
                // Registry COLORREF is AABBGGRR, unlike DWM's AARRGGBB.
                using (var k = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Explorer\Accent"))
                {
                    object value = k == null ? null : k.GetValue("AccentColorMenu");
                    if (value is int)
                    {
                        uint c = unchecked((uint)(int)value);
                        accent = 0xff000000 | ((c & 255) << 16) | (c & 0xff00) | ((c >> 16) & 255);
                    }
                }
            }
            catch (Exception e) { AppLog.Write(e); }
            Apply(dark, Color.FromRgb((byte)(accent >> 16), (byte)(accent >> 8), (byte)accent));
        }

        internal static void Apply(bool dark, Color accent)
        {
            Dark = dark;
            Set("Ink", dark ? "#F0F1F3" : "#25272B");
            Set("Muted", dark ? "#B8BCC4" : "#646970");
            Set("Surface", dark ? "#CC292B30" : "#CCFFFFFF");
            Set("Edge", dark ? "#30FFFFFF" : "#C0FFFFFF");
            Set("Hover", dark ? "#FF45484E" : "#FFF1F2F4");
            Set("Track", dark ? "#FF575B63" : "#FFD1D4DA");
            Set("Knob", dark ? "#FFF3F4F6" : "#FFFFFFFF");
            Set("WindowTint", dark ? "#50202429" : "#35F5F7FA");
            Set("Sidebar", dark ? "#18202020" : "#28FFFFFF");
            Set("Fallback", dark ? "#FF24262A" : "#FFF0F1F3");
            // Preserve system hue, while keeping controls visible on both backgrounds.
            double l = .2126 * accent.R + .7152 * accent.G + .0722 * accent.B;
            if (dark && l < 125) accent = Mix(accent, Colors.White, .4);
            if (!dark && l > 180) accent = Mix(accent, Colors.Black, .3);
            Put("Accent", accent);
            Put("Selected", Color.FromArgb(dark ? (byte)90 : (byte)35, accent.R, accent.G, accent.B));
            foreach (Window w in Application.Current.Windows)
                if (new System.Windows.Interop.WindowInteropHelper(w).Handle != IntPtr.Zero) Desktop.Apply(w);
        }
        static Color Mix(Color a, Color b, double t)
        {
            return Color.FromRgb((byte)(a.R*(1-t)+b.R*t), (byte)(a.G*(1-t)+b.G*t), (byte)(a.B*(1-t)+b.B*t));
        }
        static void Set(string key, string color) { Put(key, (Color)ColorConverter.ConvertFromString(color)); }
        static void Put(string key, Color c)
        {
            var old = Application.Current.Resources[key] as SolidColorBrush;
            if (old != null && old.Color == c) return;
            var brush = new SolidColorBrush(c); brush.Freeze();
            Application.Current.Resources[key] = brush;
        }
    }
}

