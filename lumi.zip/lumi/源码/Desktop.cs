using System;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shell;

namespace lumi
{
    internal static class Desktop
    {
        [StructLayout(LayoutKind.Sequential)]
        internal struct Point
        {
            internal int X, Y;
        }

        [StructLayout(LayoutKind.Sequential)]
        internal struct Rect
        {
            internal int Left, Top, Right, Bottom;
            internal bool Contains(Point p, int pad)
            {
                return p.X >= Left - pad && p.X <= Right + pad && p.Y >= Top - pad && p.Y <= Bottom + pad;
            }
        }

        [StructLayout(LayoutKind.Sequential)]
        internal struct Monitor
        {
            internal int Size;
            internal Rect Bounds, Work;
            internal uint Flags;
        }

        [StructLayout(LayoutKind.Sequential)]
        struct Margins
        {
            public int Left, Right, Top, Bottom;
        }

        [DllImport("dwmapi.dll")]
        internal static extern int DwmSetWindowAttribute(IntPtr h, int attr, ref int value, int size);
        [DllImport("dwmapi.dll")]
        internal static extern int DwmGetWindowAttribute(IntPtr h, int attr, out int value, int size);
        [DllImport("dwmapi.dll")]
        static extern int DwmExtendFrameIntoClientArea(IntPtr h, ref Margins margins);
        [DllImport("user32.dll")]
        internal static extern bool GetCursorPos(out Point point);
        [DllImport("user32.dll")]
        internal static extern bool GetWindowRect(IntPtr h, out Rect rect);
        [DllImport("user32.dll")]
        static extern IntPtr MonitorFromPoint(Point p, uint flags);
        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        static extern bool GetMonitorInfo(IntPtr monitor, ref Monitor info);
        [DllImport("user32.dll")]
        internal static extern bool SetWindowPos(IntPtr h, IntPtr after, int x, int y, int cx, int cy, uint flags);
        [DllImport("user32.dll")]
        internal static extern uint GetDpiForWindow(IntPtr h);
        [DllImport("user32.dll")]
        internal static extern bool SetForegroundWindow(IntPtr h);
        [DllImport("user32.dll")]
        internal static extern bool DestroyIcon(IntPtr icon);
        [DllImport("shell32.dll", CharSet = CharSet.Unicode)]
        static extern uint ExtractIconEx(string file, int index, out IntPtr large, out IntPtr small, uint n);
        [DllImport("user32.dll", CharSet = CharSet.Unicode)]
        internal static extern uint RegisterWindowMessage(string name);
        [DllImport("user32.dll")]
        internal static extern bool PostMessage(IntPtr window, uint message, IntPtr w, IntPtr l);
        [DllImport("user32.dll")]
        internal static extern IntPtr CreateIconFromResourceEx(byte[] data, uint size, bool icon, uint version, int width, int height, uint flags);
        internal static IntPtr Icon, SmallIcon, TrayIcon;
        internal static void LoadIcon()
        {
            ExtractIconEx(Assembly.GetExecutingAssembly().Location, 0, out Icon, out SmallIcon, 1);
            using (var stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("tray.png"))
            using (var data = new System.IO.MemoryStream())
            {
                stream.CopyTo(data);
                byte[] bytes = data.ToArray();
                TrayIcon = CreateIconFromResourceEx(bytes, (uint)bytes.Length, true, 0x30000, 32, 32, 0);
                if (TrayIcon == IntPtr.Zero) throw new InvalidOperationException("无法加载托盘图标");
            }
        }

        internal static void ReleaseIcons()
        {
            if (TrayIcon != IntPtr.Zero) DestroyIcon(TrayIcon);
            if (Icon != IntPtr.Zero)
                DestroyIcon(Icon);
            if (SmallIcon != IntPtr.Zero)
                DestroyIcon(SmallIcon);
        }

        internal static void Configure(Window w, bool compact)
        {
            // Keep a normal composited HWND: no layered WPF window or bitmap-shadow visual trees.
            WindowChrome.SetWindowChrome(w, new WindowChrome { CaptionHeight = compact ? 0 : 48, ResizeBorderThickness = new Thickness(compact ? 0 : 6), CornerRadius = new CornerRadius(8), GlassFrameThickness = new Thickness(-1), UseAeroCaptionButtons = false });
            TextOptions.SetTextFormattingMode(w, TextFormattingMode.Display);
            TextOptions.SetTextRenderingMode(w, TextRenderingMode.ClearType);
            TextOptions.SetTextHintingMode(w, TextHintingMode.Fixed);
            w.UseLayoutRounding = true;
            w.SnapsToDevicePixels = true;
            if (Icon != IntPtr.Zero)
                w.Icon = Imaging.CreateBitmapSourceFromHIcon(Icon, Int32Rect.Empty, BitmapSizeOptions.FromEmptyOptions());
            w.SourceInitialized += delegate
            {
                Apply(w);
            };
        }

        internal static int Apply(Window w)
        {
            IntPtr h = new WindowInteropHelper(w).Handle;
            var source = HwndSource.FromHwnd(h);
            if (source != null)
                source.CompositionTarget.BackgroundColor = Colors.Transparent;
            var margins = new Margins
            {
                Left = -1,
                Right = -1,
                Top = -1,
                Bottom = -1
            };
            DwmExtendFrameIntoClientArea(h, ref margins);
            int corner = 2, light = SystemTheme.Dark ? 1 : 0, backdrop = 3, border = unchecked((int)0xFFFFFFFF);
            DwmSetWindowAttribute(h, 33, ref corner, 4);
            DwmSetWindowAttribute(h, 20, ref light, 4);
            DwmSetWindowAttribute(h, 34, ref border, 4);
            int result = DwmSetWindowAttribute(h, 38, ref backdrop, 4);
            if (result != 0)
                w.SetResourceReference(Window.BackgroundProperty, "Fallback");
            return result;
        }

        internal static void Place(Window w, Rect anchor)
        {
            var point = new Point
            {
                X = (anchor.Left + anchor.Right) / 2,
                Y = (anchor.Top + anchor.Bottom) / 2
            };
            IntPtr monitor = MonitorFromPoint(point, 2);
            var info = new Monitor
            {
                Size = Marshal.SizeOf(typeof(Monitor))
            };
            GetMonitorInfo(monitor, ref info);
            IntPtr h = new WindowInteropHelper(w).Handle;
            // First move onto the tray's monitor so GetDpiForWindow returns that monitor's scale.
            SetWindowPos(h, IntPtr.Zero, info.Work.Left + 16, info.Work.Top + 16, 0, 0, 0x15);
            double scale = GetDpiForWindow(h) / 96.0;
            int width = (int)Math.Ceiling(w.Width * scale), height = (int)Math.Ceiling(w.Height * scale), gap = (int)(12 * scale);
            int x = anchor.Right - width, y = anchor.Top - height - gap;
            if (y < info.Work.Top)
                y = anchor.Bottom + gap;
            x = Math.Max(info.Work.Left + gap, Math.Min(x, info.Work.Right - width - gap));
            y = Math.Max(info.Work.Top + gap, Math.Min(y, info.Work.Bottom - height - gap));
            SetWindowPos(h, new IntPtr(-1), x, y, width, height, 0x10);
        }
    }
}

