using System;
using System.IO;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using Microsoft.Win32;

namespace lumi
{
    internal static class Views
    {
        static bool loaded;
        internal static Window Load(string resource)
        {
            if (!loaded)
            {
                using (var s = Assembly.GetExecutingAssembly().GetManifestResourceStream("Theme.xaml"))
                    Application.Current.Resources = (ResourceDictionary)XamlReader.Load(s);
                loaded = true;
                SystemTheme.Reload();
            }

            using (var s = Assembly.GetExecutingAssembly().GetManifestResourceStream(resource))
                return (Window)XamlReader.Load(s);
        }

        internal static T Get<T>(Window w, string name)
            where T : FrameworkElement
        {
            return (T)w.FindName(name);
        }

        internal static void Click(Window w, string name, Action action)
        {
            Get<Button>(w, name).Click += delegate
            {
                action();
            };
        }

        internal static void Wheel(object sender, MouseWheelEventArgs e)
        {
            var slider = sender as Slider;
            if (slider != null && slider.IsEnabled)
            {
                slider.Value = Math.Max(0, Math.Min(100, slider.Value + (e.Delta > 0 ? 1 : -1)));
                e.Handled = true;
            }
        }

        internal static void WheelSliders(DependencyObject root)
        {
            for (int i = 0; i < VisualTreeHelper.GetChildrenCount(root); i++)
            {
                var child = VisualTreeHelper.GetChild(root, i);
                var slider = child as Slider;
                if (slider != null)
                {
                    slider.PreviewMouseWheel -= Wheel;
                    slider.PreviewMouseWheel += Wheel;
                }
                else
                    WheelSliders(child);
            }
        }

        internal static void SetIcon(Window w)
        {
            if (w.Icon != null)
                if (Get<Image>(w, "Logo") != null) Get<Image>(w, "Logo").Source = w.Icon;
        }
    }

    internal sealed class MainView
    {
        internal readonly Window Window;
        readonly DisplayService service;
        bool changing;
        internal MainView(DisplayService service, AppHost host)
        {
            this.service = service;
            Window = Views.Load("MainWindow.xaml");
            Window.DataContext = service;
            Desktop.Configure(Window, false);
            Views.SetIcon(Window);
            var screens = Views.Get<ListBox>(Window, "Screens");
            screens.SelectedIndex = 0;
            Action rebuilt = delegate
            {
                screens.SelectedIndex = 0;
            };
            service.Rebuilt += rebuilt;
            Window.Closed += delegate
            {
                service.Rebuilt -= rebuilt;
            };
            Window.Loaded += delegate
            {
                Views.WheelSliders(Window);
            };
            Views.Click(Window, "Close", () => Window.Close());
            Views.Click(Window, "Minimize", () => Window.WindowState = WindowState.Minimized);
            Views.Click(Window, "Maximize", () => Window.WindowState = Window.WindowState == WindowState.Maximized ? WindowState.Normal : WindowState.Maximized);
            Views.Click(Window, "Quick", () => host.OpenQuick(true));
            Views.Click(Window, "Refresh", async () => await service.Scan());
            Views.Click(Window, "Info", async delegate
            {
                Page("Info");
                try
                {
                    Views.Get<TextBox>(Window, "Report").Text = await service.Diagnostics();
                }
                catch (Exception e)
                {
                    service.Message(e.Message);
                }
            });
            Views.Click(Window, "BackInfo", () => Page("Display"));
            Views.Click(Window, "BackSettings", () => Page("Display"));
            Views.Click(Window, "Settings", () => Page("Settings"));
            Action refreshIcons = delegate
            {
                byte[] saved = File.Exists(TrayIconSettings.FilePath) ? File.ReadAllBytes(TrayIconSettings.FilePath) : null;
                for (int i = 1; i <= 3; i++)
                {
                    byte[] icon = TrayIconSettings.Option(i);
                    var bitmap = new System.Windows.Media.Imaging.BitmapImage();
                    using (var input = new MemoryStream(icon)) { bitmap.BeginInit(); bitmap.CacheOption = System.Windows.Media.Imaging.BitmapCacheOption.OnLoad; bitmap.StreamSource = input; bitmap.EndInit(); bitmap.Freeze(); }
                    Views.Get<Image>(Window, "OptionImage" + i).Source = bitmap;
                    bool selected = saved == null ? i == 3 : Convert.ToBase64String(saved) == Convert.ToBase64String(icon);
                    var button = Views.Get<Button>(Window, "IconOption" + i);
                    button.SetResourceReference(Control.BackgroundProperty, selected ? "Selected" : "Surface");
                    button.SetResourceReference(Control.BorderBrushProperty, selected ? "Accent" : "Edge");
                    Views.Get<TextBlock>(Window, "OptionState" + i).Text = selected ? "已选用" : "选择";
                }
            };
            refreshIcons();
            for (int i = 1; i <= 3; i++)
            {
                int option = i;
                Views.Click(Window, "IconOption" + i, delegate
                {
                    try { host.Tray.ChangeIconBytes(TrayIconSettings.Option(option), false); refreshIcons(); service.Message("托盘图标已更新并保存。"); }
                    catch (Exception e) { service.Message(e.Message); }
                });
            }
            Views.Click(Window, "Windows", delegate
            {
                try
                {
                    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo("ms-settings:display") { UseShellExecute = true });
                }
                catch (Exception e)
                {
                    service.Message(e.Message);
                }
            });
            Views.Click(Window, "Export", delegate
            {
                var dialog = new SaveFileDialog
                {
                    Filter = "文本文件 (*.txt)|*.txt",
                    FileName = "lumi-诊断.txt"
                };
                if (dialog.ShowDialog(Window) == true)
                    try
                    {
                        File.WriteAllText(dialog.FileName, Views.Get<TextBox>(Window, "Report").Text);
                        service.Message("诊断已保存。");
                    }
                    catch (Exception e)
                    {
                        service.Message(e.Message);
                    }
            });
            foreach (int value in new[]
            {
                25,
                50,
                75,
                100
            }

            )
            {
                int n = value;
                Views.Click(Window, "P" + n, () => SetBrightness(n));
            }

            Views.Get<Slider>(Window, "Brightness").ValueChanged += delegate (object sender, RoutedPropertyChangedEventArgs<double> e)
            {
                if (changing || service.Busy || Views.Get<CheckBox>(Window, "Link").IsChecked != true || !Views.Get<Slider>(Window, "Brightness").IsKeyboardFocusWithin && !Views.Get<Slider>(Window, "Brightness").IsMouseCaptureWithin)
                    return;
                changing = true;
                foreach (var s in service.Screens)
                    if (s.CanBrightness)
                        s.Brightness = (int)e.NewValue;
                changing = false;
            };
            Views.Get<CheckBox>(Window, "Hdr").Click += async delegate
            {
                var selected = screens.SelectedItem as ScreenModel;
                bool enabled = Views.Get<CheckBox>(Window, "Hdr").IsChecked == true;
                await service.SetHdr(selected, enabled);
                if (selected != null)
                    selected.Notify("HdrEnabled");
            };
            Views.Click(Window, "Restore", delegate
            {
                var selected = screens.SelectedItem as ScreenModel;
                if (selected == null)
                    return;
                Views.Get<CheckBox>(Window, "Link").IsChecked = false;
                if (selected.CanBrightness)
                    selected.Brightness = selected.Device.InitialBrightness;
                if (selected.CanContrast)
                    selected.Contrast = selected.Device.InitialContrast;
            });
            var startup = Views.Get<CheckBox>(Window, "Startup");
            try
            {
                using (var key = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Run"))
                    startup.IsChecked = key != null && key.GetValue("lumi") != null;
            }
            catch (Exception e)
            {
                AppLog.Write(e);
            }

            startup.Click += delegate
            {
                bool desired = startup.IsChecked == true;
                try
                {
                    using (var key = Registry.CurrentUser.CreateSubKey(@"Software\Microsoft\Windows\CurrentVersion\Run"))
                    {
                        if (desired)
                            key.SetValue("lumi", "\"" + Assembly.GetExecutingAssembly().Location + "\" --tray");
                        else
                            key.DeleteValue("lumi", false);
                    }

                    service.Message("登录启动设置已保存。");
                }
                catch (Exception e)
                {
                    startup.IsChecked = !desired;
                    service.Message(e.Message);
                }
            };
        }

        internal void Page(string name)
        {
            Views.Get<ScrollViewer>(Window, "DisplayPage").Visibility = name == "Display" ? Visibility.Visible : Visibility.Collapsed;
            Views.Get<Grid>(Window, "InfoPage").Visibility = name == "Info" ? Visibility.Visible : Visibility.Collapsed;
            Views.Get<ScrollViewer>(Window, "SettingsPage").Visibility = name == "Settings" ? Visibility.Visible : Visibility.Collapsed;
        }

        void SetBrightness(int value)
        {
            if (service.Busy)
                return;
            if (Views.Get<CheckBox>(Window, "Link").IsChecked == true)
            {
                foreach (var s in service.Screens)
                    if (s.CanBrightness)
                        s.Brightness = value;
            }
            else
            {
                var s = Views.Get<ListBox>(Window, "Screens").SelectedItem as ScreenModel;
                if (s != null && s.CanBrightness)
                    s.Brightness = value;
            }
        }
    }

    internal sealed class QuickView
    {
        internal readonly Window Window;
        internal QuickView(DisplayService service, AppHost host)
        {
            Window = Views.Load("QuickWindow.xaml");
            Window.DataContext = service;
            Desktop.Configure(Window, true);
            Views.SetIcon(Window);
            Views.Click(Window, "Dismiss", () => host.HideQuick());
            Views.Click(Window, "OpenMain", () => host.ShowMain());
            Action resize = delegate
            {
                Window.Height = Math.Min(420, 66 + Math.Max(1, service.Screens.Count) * 76);
                if (Window.IsVisible) Desktop.Place(Window, host.Tray.Anchor());
                Views.WheelSliders(Window);
            };
            service.Rebuilt += resize;
            Window.Closed += delegate { service.Rebuilt -= resize; };
            Window.Loaded += delegate
            {
                Views.WheelSliders(Window);
            };
            Window.PreviewKeyDown += delegate (object sender, KeyEventArgs e)
            {
                if (e.Key == Key.Escape)
                {
                    host.HideQuick();
                    e.Handled = true;
                }
            };
            Window.PreviewMouseDown += delegate
            {
                host.QuickEngaged();
            };
            Window.Deactivated += delegate
            {
                host.QuickDeactivated();
            };
        }
    }
}



